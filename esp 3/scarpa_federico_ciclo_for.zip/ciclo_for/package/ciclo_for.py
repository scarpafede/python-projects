# ciclo_for.py: insieme di quattro esercizi assegnati per casa; Scarpa Federico; 27/10/2022
if __name__ == "__main__":
    è_testo = 1
    while è_testo == 1:
        try:
            print("Esercizio 1, conto alla rovescia a partire da un numero compreso tra 60 e 120")
            print("Esercizio 2, somma di due numeri (una unità alla volta)")
            print("Esercizio 3, prodotto di due numeri (procedendo per addizioni successive)")
            print("Esercizio 4, media alunni di una classe di tot persone")
            esercizio = int(input("Quale esercizio vuole eseguire? 1, 2, 3 o 4? "))
            while esercizio != 1 and esercizio != 2 and esercizio != 3 and esercizio != 4:
                esercizio = int(input("Vuoi eseguire il numero 1, 2, 3 o 4? "))
            è_testo = 0
        except:
            print("Si prega di inserire numeri")

    if esercizio == 1:
        # esercizio 1: conto alla rovescia; Scarpa Federico; 27/10/2022
        print("Esecuzione esercizio 1")
        è_testo_2 = 1
        while è_testo_2 == 1:
            try:
                numero = int(input("Inserisci un numero tra 60 e 120, sul quale si eseguirà il conto alla rovescia: "))
                while numero < 60 or numero > 120:
                    numero = int(input("Impossibile, ridimmi il numero, che deve essere compreso tra 60 e 120: "))
                for numero in range(numero, -1, -1):
                    print(numero)
                è_testo_2 = 0
            except:
                print("Dammi un valore numerico e riparti")

    elif esercizio == 2:  
        # esercizio 2: somma di due numeri un'unità alla volta; Scarpa Federico; 31/10/2022
        print("Esecuzione esercizio 2")
        è_testo_3 = 1
        while è_testo_3 == 1:
            try:
                num = int(input("Inserire il primo numero, che si vuole far sommare al prossimo: "))
                num2 = int(input("Inserire il secondo numero, quello da sommare al primo: "))
                è_testo_3 = 0
                for n in range(num2):
                    num = num + 1
                print("La somma dei due numeri è" , num)
            except:
                print("Dammi un valore numerico e riparti")

    elif esercizio == 3:
        # esercizio 3: prodotto di due numeri per unità successive; Scarpa Federico; 31/10/2022
        print("Esecuzione esercizio 3")
        è_testo_4 = 1
        while è_testo_4 == 1:
            try:
                primo = int(input("Inserire il primo numero, che si vuole far moltiplicare al prossimo: "))
                volte = int(input("Inserire il secondo numero, quello da moltiplicare al primo: "))
                volte = volte - 1
                numero_primo_iniziale = primo
                è_testo_4 = 0
                for i in range(volte):
                    primo = primo + numero_primo_iniziale
                print("Il prodotto tra i due numeri vale" , primo)
            except:
                print("Dammi un valore numerico e riparti")

    elif esercizio == 4:
        # esercizio 4: media alunni di una classe di tot persone; Scarpa Federico; 31/10/2022
        print("Esecuzione esercizio 4")
        è_testo_5 = 1
        while è_testo_5 == 1:
            try:
                nalunni = int(input("Inserire il numero di alunni presenti nella classe: "))
                conto_parziale = 0
                quante_volte = 0
                for t in range(nalunni):
                    voti_o = 12
                    while voti_o < 1 or voti_o > 10:
                        voti_o = float(input("Inserire i vari voti, uno alla volta (per ripartire inserire una lettera o un numero non compreso tra 1 e 10): "))
                    conto_parziale = conto_parziale + voti_o
                    quante_volte = quante_volte + 1
                è_testo_5 = 0
                media = conto_parziale / quante_volte
                print("La media è" , media)
            except:
                print("Riparti (e dammi un valore numerico)")
