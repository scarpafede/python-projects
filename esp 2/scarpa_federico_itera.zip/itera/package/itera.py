# itera.py: insieme di due esercizi consegnati per casa; Scarpa Federico; 20/10/2022
if __name__ == "__main__":
    è_testo_3 = 1
    while è_testo_3 == 1:
        try:
            esercizio = int(input("Quale esercizio vuole eseguire? 1 o 2? "))
            while esercizio != 1 and esercizio != 2:
                esercizio = int(input("Vuoi eseguire il numero 1 o il 2? "))
            è_testo_3 = 0
        except:
            print("Si prega di inserire numeri")
    if esercizio == 1:
        # esercizio 1: validazione input; Scarpa Federico; 19/10/2022
        print("Esecuzione esercizio 1")
        è_testo_2 = 1
        while è_testo_2 == 1:
            try:
                numero = int(input("Inserisci un numero tra 60 e 120 "))
                while numero < 60 or numero > 120:
                    numero = int(input("Impossibile, ridimmi il numero "))
                conto = numero
                è_testo_2 = 0
                while conto > -1:
                    print(conto)
                    conto = conto -1
            except:
                print("Dammi un valore numerico")
    else:
        # esercizio 2: base, soglia e potenza; Scarpa Federico; 19/10/2022
        print("Esecuzione esercizio 2")
        è_testo = 1
        while è_testo == 1:
            try:
                base = int(input("Inserisci la base "))
                soglia = int(input("Inserisci la soglia "))
                potenza = base
                while potenza < soglia:
                    potenza = potenza * potenza
                print(potenza)
                è_testo = 0
            except:
                print("Dammi un valore numerico e riparti")
