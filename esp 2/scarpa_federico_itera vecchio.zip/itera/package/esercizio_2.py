# esercizio 2: base, soglia e potenza; Scarpa Federico; 19/10/2022
è_testo = 1
while è_testo == 1:
    try:
        base = int(input("Inserisci la base "))
        soglia = int(input("Inserisci la soglia "))
        potenza = base
        while potenza < soglia:
            potenza = potenza * potenza
        print(potenza)
        è_testo = 0
    except:
        print("Dammi un valore numerico e riparti")
