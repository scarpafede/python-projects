# esercizio 1: validazione input; Scarpa Federico; 19/10/2022
if __name__ == "__main__":
    
    non_è_testo = 1
    while non_è_testo == 1:
        try:
            numero = int(input("Inserisci un numero "))
            while numero < 60 or numero > 120:
                numero = int(input("Impossibile, ridimmi il numero "))
            non_è_testo = 0
            conto = numero
            while conto > -1:
                print(conto)
                conto = conto -1
        except:
            print("Dammi un valore numerico")
